import socket
import jsons
import argparse
import time
import os

HOST = '127.0.0.1'
PORT = 8000
clientMessage = 'Hello!'
parser = argparse.ArgumentParser(description='train')
parser.add_argument('-p', '--port', type=str, default='8080', help="port")
args = parser.parse_args()

if __name__ == '__main__':
    while True:
        time.sleep(1)
        if os.path.getsize("/home/lumiawjf/BFLC/BCFL/start.txt")!=0:
            print("\n\n I'm coming! \n\n")
            break
    if args.port=="8081":
        time.sleep(1)
    else:
        time.sleep(2)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))
    path = 'hash.txt'
    IPFS=[]
    with open(path) as f:
        IPFS = f.readlines()
    if args.port=="8081":
        LM_IPFS = IPFS[0].replace("\n", "")
    else :
        LM_IPFS = IPFS[1].replace("\n", "")

    print("I'm "+ args.port)
    info_json={}

    # Local Model IPFS hash
    info_json['LM_IPFS'] = LM_IPFS
    print("info_json['LM_IPFS']", info_json['LM_IPFS'])

    # Client Number
    info_json['Client_Num'] = args.port
    jsonstr = jsons.dumps(info_json)
    print('\n\njsonstr is : ', jsonstr)
    client.sendall(jsonstr.encode())
    
    while True:
        time.sleep(1)
        
        Message = str(client.recv(1024), encoding='utf-8')
        if Message == None:
            Message="{""serverMessage"" : ""NOT YET"",""done_Num"": 0 }"
        print(Message)

        info_json = jsons.loads(Message)
        serverMessage = info_json['serverMessage']
        done_Num = info_json['done_Num']
        print('Server:', done_Num)
        print('Server:', serverMessage)
        
        if done_Num ==2:
            break

    client.close()
    while True:
        time.sleep(2)
        print(os.path.getsize("/home/lumiawjf/BFLC/BCFL/hash.txt"))
        if os.path.getsize("/home/lumiawjf/BFLC/BCFL/hash.txt")==0 :
            print("\n\nI'm leaving!\n\n")
            break