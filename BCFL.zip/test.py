import ipfshttpclient
import jsons
hash_ipfs = "QmRm8LoP9GY4249KSLKzFh5kxqr6vNSedh43Hqnv7CqZzs"
api = ipfshttpclient.connect('/ip4/127.0.0.1/tcp/5001/http') 
line = str(api.cat(hash_ipfs))
line = line.replace('\'', '\"')
line = line[2:len(line)-1]
print(line)
print(len(line))
weight = jsons.loads(line)